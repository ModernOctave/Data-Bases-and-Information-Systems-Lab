# Server
The server is a RESTful API that provides access to the data and authenticates users with passport.js local and session strategy. The server is designed using expressjs.

# API documentation
[Authentication](https://documenter.getpostman.com/view/18152083/2s8YRdsbPX)

[Courses](https://documenter.getpostman.com/view/18152083/2s8YRdsbPY)

[Posts](https://documenter.getpostman.com/view/18152083/2s8YRdsbPZ)

[Slots](https://documenter.getpostman.com/view/18152083/2s8YRdsbPb)
