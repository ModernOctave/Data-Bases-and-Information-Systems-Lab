# Client
## UI
All the react components are present in the in `src/components` folder.
All hooks are present in the `src/hooks` folder.

we are using Context to store the common data such username of the logged in users.

## Fetching data

Data is fecthed from the server using axios. Server url should be provided in the `.env` file.



